import { useState } from 'react'
import ToDoList from '../ToDoList/ToDoList';


export default function Create() {
  const [name, setName] = useState("")
  const [item, setItem] = useState([])

  const itemEvent = (event) => {

    setName(event.target.value)

  };



  const listOfItemt = () => {

      

      setItem((oldItem) => {

        return [...oldItem, name]
      });
      

    }
 

  const deleteItem = (id) => {
    console.log("delete")

    setItem((oldItem) => {
      return oldItem.filter((arrElement, index) => {
        return index !== id;
      })

    });
  };

  return (
    <>
      <div className="container">
        <div class="row">
          <div className="col-8 mx-auto">
            <h1>To Do List</h1>
            <br />
            <input className='form-control' type="text" placeholder='to do' size={100}
              value={name}
              onChange={itemEvent} />
            <button className='btn btn-success m-2' onClick={listOfItemt}>Add</button>


            <ol>
              {item.map((sajjad, index) => {
                return <ToDoList key={index}
                  id={index}
                  text={sajjad}
                  onSelect={deleteItem}
                />;

              })}
            </ol>
          </div>
        </div>
      </div>

    </>

  );
}
