import React from 'react'

const ToDoList = (props) => {



    return (
        <>



            <div className="container">
                <div class="row">
                    <div className="col-8 mx-auto my-3">
                        <div class="card">

                            <div class="card-body">
                                <h4 class="card-title">Todo Today List</h4>
                                <p class="card-text">{props.text}</p>
                                <button className="btn btn-danger" onClick={() => {
                                    props.onSelect(props.id)
                                }}>Remove</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )

}

export default ToDoList;